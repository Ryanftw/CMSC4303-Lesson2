package edu.uco.rlorenz.map.lesson2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
